// Force SIMULATION_MODE to false globally
process.env.SIMULATION_MODE = "false";

const express = require("express");
const http = require("http");
const path = require("path");
const { MongoClient, ObjectId } = require("mongodb");
const { Server } = require("socket.io");
const { Scraper } = require("agent-twitter-client");
const { TwitterApi } = require("twitter-api-v2");
const { spawn, exec } = require("child_process");
require("dotenv").config();

// Set simulation mode from environment variables or default to true for testing
const SIMULATION_MODE = process.env.SIMULATION_MODE === "false" ? false : true;
console.log(
  `[INFO] Running in ${SIMULATION_MODE ? "SIMULATION" : "PRODUCTION"} mode`
);

// Define server port
const PORT = process.env.PORT || 3000;

// Set proper encoding for emojis
process.env.NODE_ENV = "production";
process.env.NODE_OPTIONS = "--no-warnings";

// Initialize Express app and HTTP server
const app = express();
const server = http.createServer(app);

// Configure Socket.IO with better connection settings
const io = new Server(server, {
  pingTimeout: 60000, // Increase ping timeout to 60 seconds (default is 20s)
  pingInterval: 25000, // Ping interval to 25 seconds (default is 25s)
  connectTimeout: 45000, // Connection timeout to 45 seconds
  maxHttpBufferSize: 1e8, // 100 MB (increased from default 1MB)
  transports: ["websocket", "polling"], // Try WebSocket first, fall back to polling
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
  allowEIO3: true, // Allow Engine.IO v3 client (for compatibility)
});

// Disable Socket.IO binary detection for state objects
io.engine.binaryType = "arraybuffer";

// Configuration
const config = {
  MONGODB_URI:
    process.env.MONGODB_URI ||
    "mongodb+srv://shade:TRrs0tzVQGEDtK7Z@lore.r53ru.mongodb.net/?retryWrites=true&w=majority&appName=LORE",
  MONGODB_DB: "lure", // Force the correct database name
  MONGODB_COLLECTION: "graduation_tokens", // Force the correct collection name
  TWITTER_USERNAME: process.env.TWITTER_USERNAME || "Ai16zSolana",
  TWITTER_PASSWORD: process.env.TWITTER_PASSWORD || "12Dagga34??",
  TWITTER_EMAIL: process.env.TWITTER_EMAIL || "big.trip.ox@gmail.com",
  SCAN_INTERVAL: 15000, // Changed from 30000 to 15000 as requested
  LIQUIDITY_THRESHOLD: 10000,
  LIQUIDITY_RECHECK_INTERVAL: 10000,
  TWITTER_API_KEY: process.env.TWITTER_API_KEY,
  TWITTER_API_SECRET: process.env.TWITTER_API_SECRET,
  TWITTER_ACCESS_TOKEN: process.env.TWITTER_ACCESS_TOKEN,
  TWITTER_ACCESS_SECRET: process.env.TWITTER_ACCESS_SECRET,
};

// Initialize dashboard state
const dashboardState = {
  logs: [],
  activities: [],
  agentRunning: false,
  lastScan: null,
  lastTweet: null,
  mongoCount: 0,
  mongoConnected: false,
  twitterConnected: false,
  processedTokenIds: new Set(),
  scanInterval: null,
  tweetedTokens: [],
};

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Set proper content type for emoji support
app.use((req, res, next) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  next();
});

// Routes
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "dashboard.html"));
});

app.get("/api/status", (req, res) => {
  res.json(dashboardState);
});

app.post("/api/agent/start", (req, res) => {
  if (!dashboardState.agentRunning) {
    dashboardState.agentRunning = true;
    dashboardState.startTime = new Date();
    addLog("Agent started", "info");
    io.emit("stateUpdate", dashboardState);

    // Start scanning for tokens
    startTokenScanning();

    res.json({ success: true, message: "Agent started successfully" });
  } else {
    res.json({ success: false, message: "Agent is already running" });
  }
});

app.post("/api/agent/stop", (req, res) => {
  if (dashboardState.agentRunning) {
    dashboardState.agentRunning = false;
    addLog("Agent stopped", "info");
    io.emit("stateUpdate", dashboardState);
    res.json({ success: true, message: "Agent stopped successfully" });
  } else {
    res.json({ success: false, message: "Agent is not running" });
  }
});

// Set up socket.io events with improved connection handling
io.on("connection", (socket) => {
  // Track connection count
  connectionCount++;
  console.log(
    `[INFO] New client connected (${connectionCount} active connections)`
  );
  addLog(
    `New client connected (${connectionCount} active connections)`,
    "info"
  );

  // Limit the number of connections to prevent overload
  if (connectionCount > 10) {
    console.warn(
      `[WARNING] Too many connections (${connectionCount}). Consider restarting server.`
    );
    addLog(
      `Too many connections (${connectionCount}). Consider restarting server.`,
      "warning"
    );
  }

  // Send initial data to the client with rate limiting
  // Use setTimeout to add a small delay to prevent connection flooding
  setTimeout(() => {
    sendInitialData(socket);
  }, connectionCount * 100); // Stagger connections slightly

  // Handle start agent request
  socket.on("startAgent", async () => {
    console.log("[INFO] Received startAgent request from client");
    addLog("Client requested to start agent", "info");

    if (await startAgent()) {
      socket.emit("agentStarted");
      addLog("Agent started successfully", "success");
    } else {
      socket.emit("agentStartError", { message: "Failed to start agent" });
      addLog("Failed to start agent", "error");
    }
  });

  // Handle stop agent request
  socket.on("stopAgent", () => {
    console.log("[INFO] Received stopAgent request from client");
    addLog("Client requested to stop agent", "info");

    if (stopAgent()) {
      socket.emit("agentStopped");
      addLog("Agent stopped successfully", "info");
    } else {
      socket.emit("agentStopError", { message: "Failed to stop agent" });
      addLog("Failed to stop agent", "error");
    }
  });

  // Handle debug data request
  socket.on("getDebugData", () => {
    console.log("[INFO] Client requested debug data");

    // Send comprehensive debug data
    socket.emit("debugData", {
      dashboardState: createSafeObject(dashboardState),
      mongoConnected: !!mongoClient,
      activitiesCount: dashboardState.activities
        ? dashboardState.activities.length
        : 0,
      latestToken: dashboardState.latestToken
        ? createSafeObject(dashboardState.latestToken)
        : null,
      systemStatus: getSystemStatus(),
      connectionCount,
      activeRequests,
    });
  });

  // Handle disconnection - clean up connection count
  socket.on("disconnect", () => {
    connectionCount--;
    console.log(
      `[INFO] Client disconnected (${connectionCount} active connections)`
    );
  });

  // Handle refresh data requests
  socket.on("refreshData", async () => {
    addLog("Manual refresh requested", "info");

    // If connected to MongoDB, get latest data
    if (dashboardState.mongoConnected && mongoClient) {
      try {
        await scanForNewTokens();
      } catch (error) {
        console.error(`[ERROR] Refresh data failed: ${error.message}`);
        addLog(`Refresh data failed: ${error.message}`, "error");
      }
    } else {
      // Try to reconnect to MongoDB
      addLog("Attempting to connect to MongoDB for refresh...", "info");
      const connected = await initMongoDB();

      if (connected) {
        try {
          await scanForNewTokens();
        } catch (error) {
          console.error(`[ERROR] Refresh data failed: ${error.message}`);
          addLog(`Refresh data failed: ${error.message}`, "error");
        }
      } else {
        addLog("Cannot refresh - MongoDB connection failed", "error");
      }
    }
  });

  // Handle tweet generation request
  socket.on("generateTweet", async (token) => {
    console.log(`Generating tweet for token: ${token.symbol}`);

    // Log the request
    addLog(`Generating tweet for ${token.symbol || "unknown token"}`, "info");
    io.emit("log", {
      message: `Generating tweet for ${token.symbol || "unknown token"}`,
      level: "info",
      timestamp: new Date(),
    });

    // Check if we should actually generate a tweet based on token status
    const status = (token.status || "").toUpperCase();
    let shouldTweet = false;
    let tweetType = "";

    if (status === "ACTIVE") {
      if (token.previousStatus === "SURVIVAL") {
        shouldTweet = true;
        tweetType = "recovery";
      } else if (!token.tweeted) {
        shouldTweet = true;
        tweetType = "new_active";
      }
    } else if (status === "SURVIVAL" && !token.tweeted) {
      shouldTweet = true;
      tweetType = "survival";
    }

    if (shouldTweet) {
      try {
        // Generate and post the tweet
        const tweetResult = await generateAndPostTweet(token, tweetType);

        // Update the token status in our local cache
        const updatedToken = {
          ...token,
          tweeted: true,
          status: "TWEETED",
          tweetTimestamp: new Date().toISOString(),
          tweetText: tweetResult.tweetText,
          tweetId: tweetResult.tweetId,
          tweetUrl: tweetResult.tweetUrl,
        };

        // Update our local data
        updateTokenInActivity(updatedToken);

        // Add to tweeted tokens list
        if (!dashboardState.tweetedTokens) {
          dashboardState.tweetedTokens = [];
        }
        dashboardState.tweetedTokens.unshift(updatedToken);

        // Limit the number of tweeted tokens stored
        if (dashboardState.tweetedTokens.length > 100) {
          dashboardState.tweetedTokens = dashboardState.tweetedTokens.slice(
            0,
            100
          );
        }

        // Update MongoDB if possible
        if (dashboardState.mongoConnected && mongoClient) {
          try {
            const db = mongoClient.db("lore");
            const collection = db.collection("graduation_tokens");

            await collection.updateOne(
              { _id: token._id },
              {
                $set: {
                  status: "TWEETED",
                  tweeted: true,
                  tweetTimestamp: new Date(),
                  tweetText: tweetResult.tweetText,
                  tweetId: tweetResult.tweetId,
                  tweetUrl: tweetResult.tweetUrl,
                },
              }
            );

            addLog(`Updated token ${token.symbol} in MongoDB`, "info");
          } catch (error) {
            console.error("Error updating MongoDB:", error);
            addLog(`Failed to update MongoDB: ${error.message}`, "error");
          }
        }

        // Emit updated token activity to all clients
        io.emit(
          "tokenActivity",
          dashboardState.activities.map((t) => formatToken(t))
        );
        io.emit("tweetedTokens", dashboardState.tweetedTokens);

        // Update last tweet time
        dashboardState.lastTweet = new Date().toISOString();
        io.emit("systemStatus", {
          mongoConnected: dashboardState.mongoConnected,
          twitterConnected: dashboardState.twitterConnected,
          lastScan: dashboardState.lastScan,
          lastTweet: dashboardState.lastTweet,
          mongoCount: dashboardState.mongoCount,
        });

        addLog(`Tweet generated and posted for ${token.symbol}`, "info");
      } catch (error) {
        console.error("Error generating tweet:", error);
        addLog(`Failed to generate tweet: ${error.message}`, "error");
      }
    } else {
      addLog(`No tweet needed for ${token.symbol} (status: ${status})`, "info");
    }
  });

  // Handle getTweetedTokens request
  socket.on("getTweetedTokens", async () => {
    try {
      const tokens = await fetchTweetedTokens();
      socket.emit("tweetedTokens", tokens);
    } catch (error) {
      console.error(`[ERROR] Error fetching tweeted tokens: ${error.message}`);
      addLog(`Error fetching tweeted tokens: ${error.message}`, "error");
      socket.emit("tweetedTokens", []);
    }
  });

  // Set ping timeout to higher value to prevent disconnections
  socket.conn.on("ping", () => {
    // Reset the monitor on ping
    console.log(`[INFO] Ping from client: ${socket.id.substring(0, 8)}`);
  });

  // Log errors to help troubleshoot
  socket.on("error", (error) => {
    addLog(`Socket error for ${socket.id}: ${error.message}`, "error");
  });

  // Handle initial data request
  socket.on("getInitialData", () => {
    try {
      sendInitialData(socket);
      addLog(`Sent initial data to client: ${socket.id}`, "info");
    } catch (error) {
      addLog(
        `Error sending initial data to ${socket.id}: ${error.message}`,
        "error"
      );
    }
  });

  // Handle initial state request (legacy)
  socket.on("getInitialState", () => {
    sendInitialData(socket);
  });

  // Handle data refresh requests
  socket.on("refreshData", () => {
    sendInitialData(socket);
  });

  // Handle log clearing
  socket.on("clear-logs", () => {
    dashboardState.logs = [];
    io.emit("logs", []);
    addLog("Logs cleared", "info");
  });

  // Handle token activity clearing
  socket.on("clear-token-activity", () => {
    dashboardState.activities = [];
    io.emit("tokenActivity", []);
    addLog("Token activity cleared", "info");
  });
});

// API route to force use of mock data for testing
app.get("/api/force-mock-data", (req, res) => {
  console.log("[INFO] Force mock data endpoint called - using mock token data");
  addLog("Forcing use of mock token data for testing", "info");

  useMockTokenData();

  res.json({
    success: true,
    message: "Mock data generated and displayed",
  });
});

// API route to get database status and last 10 tokens
app.get("/api/db-status", async (req, res) => {
  try {
    if (!mongoClient) {
      return res.json({
        connected: false,
        message: "MongoDB client not available",
        tokens: [],
      });
    }

    const db = mongoClient.db("lore");
    const collection = db.collection("graduation_tokens");

    // Get the most recent tokens
    const tokens = await collection
      .find({})
      .sort({ _id: -1 })
      .limit(10)
      .toArray();

    // Format tokens for display
    const formattedTokens = tokens.map((token) => ({
      _id: token._id ? token._id.toString() : "N/A",
      symbol: token.symbol || "N/A",
      name: token.name || "N/A",
      address: token.address || "N/A",
      marketCap: token.marketCap || token.mc || 0,
      status: token.status || "UNKNOWN",
    }));

    res.json({
      connected: true,
      database: db.databaseName,
      collection: collection.collectionName,
      tokenCount: await collection.countDocuments(),
      tokens: formattedTokens,
    });
  } catch (error) {
    res.json({
      connected: false,
      error: error.message,
    });
  }
});

// Add this API route after the other app.get routes
app.get("/api/debug/last-tokens", async (req, res) => {
  try {
    if (!mongoClient) {
      return res.json({
        success: false,
        error: "MongoDB client not available",
      });
    }

    // Connect to the database
    const db = mongoClient.db("lore");
    const collection = db.collection("graduation_tokens");

    console.log(
      "[DEBUG] Fetching last 10 tokens with sort: {graduatedAt: -1, scannedAt: -1}"
    );

    // Get the most recent tokens using the exact sort criteria
    const tokens = await collection
      .find({})
      .sort({ graduatedAt: -1, scannedAt: -1 })
      .limit(10)
      .toArray();

    // Map tokens to a simplified format for debugging
    const simplifiedTokens = tokens.map((token) => ({
      _id: token._id ? token._id.toString() : "unknown",
      symbol: token.symbol || "N/A",
      name: token.name || "N/A",
      marketCap: token.marketCap || token.mc || 0,
      address: token.address ? `${token.address.substring(0, 10)}...` : "N/A",
      graduatedAt: token.graduatedAt || null,
      scannedAt: token.scannedAt || null,
      status: token.status || "UNKNOWN",
    }));

    console.log(`[DEBUG] Found ${tokens.length} tokens in raw database query`);

    // Also check other database names as a test
    let lureTokens = [];
    try {
      const lureDb = mongoClient.db("lure");
      const lureCollection = lureDb.collection("graduation_tokens");
      lureTokens = await lureCollection
        .find({})
        .sort({ graduatedAt: -1, scannedAt: -1 })
        .limit(10)
        .toArray();

      console.log(
        `[DEBUG] Also found ${lureTokens.length} tokens in 'lure' database`
      );
    } catch (err) {
      console.log("[DEBUG] Error checking 'lure' database:", err.message);
    }

    return res.json({
      success: true,
      database: db.databaseName,
      collection: collection.collectionName,
      tokenCount: simplifiedTokens.length,
      tokens: simplifiedTokens,
      lureTokenCount: lureTokens.length || 0,
      hasLureDb: lureTokens.length > 0,
    });
  } catch (error) {
    console.error("[ERROR] Error in debug endpoint:", error);
    return res.json({
      success: false,
      error: error.message,
    });
  }
});

// Initialize MongoDB
let mongoClient;
let mongoDb;
let collection;

// Update initMongoDB function to prioritize the 'lure' database
async function initMongoDB() {
  console.log("[INFO] Initializing MongoDB connection...");
  addLog("Initializing MongoDB connection...", "info");

  // Close any existing connections
  if (mongoClient) {
    try {
      await mongoClient.close();
      mongoClient = null;
      console.log("[INFO] Closed existing MongoDB connection");
    } catch (err) {
      console.error("[ERROR] Error closing existing MongoDB connection:", err);
    }
  }

  // Maximum retry attempts
  const MAX_RETRIES = 3;
  let retryCount = 0;
  let connected = false;

  while (retryCount < MAX_RETRIES && !connected) {
    try {
      // Connect with retry logic
      const MONGODB_URI =
        "mongodb+srv://shade:TRrs0tzVQGEDtK7Z@lore.r53ru.mongodb.net/?retryWrites=true&w=majority&appName=LORE";

      if (retryCount > 0) {
        console.log(`[INFO] Retry attempt ${retryCount}/${MAX_RETRIES}...`);
        addLog(
          `Retrying MongoDB connection (${retryCount}/${MAX_RETRIES})...`,
          "info"
        );
      }

      // Set MongoDB connection options with better timeout values
      const options = {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        connectTimeoutMS: 30000,
        socketTimeoutMS: 45000,
        serverSelectionTimeoutMS: 60000,
        maxPoolSize: 10,
        retryWrites: true,
        retryReads: true,
      };

      // Connect to MongoDB
      mongoClient = new MongoClient(MONGODB_URI, options);

      // Try connecting with a timeout
      const connectPromise = mongoClient.connect();
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(
          () => reject(new Error("Connection timeout after 30s")),
          30000
        )
      );

      await Promise.race([connectPromise, timeoutPromise]);

      // Try multiple database names as a fallback mechanism - prioritize 'lure' database first
      let db;
      let collection;
      let count = 0;

      // First try "lure" database as that's where the user's data is
      try {
        db = mongoClient.db("lure");
        collection = db.collection("graduation_tokens");
        count = await collection.countDocuments();
        console.log(
          `[INFO] Successfully connected to 'lure' database with ${count} tokens`
        );

        // Update config to use this database
        config.MONGODB_DB = "lure";
      } catch (dbError) {
        console.log(
          `[INFO] Error accessing 'lure' database: ${dbError.message}`
        );

        // Try "lore" as a fallback database
        try {
          db = mongoClient.db("lore");
          collection = db.collection("graduation_tokens");
          count = await collection.countDocuments();
          console.log(
            `[INFO] Successfully connected to 'lore' database with ${count} tokens`
          );

          // Update config to use this database
          config.MONGODB_DB = "lore";
        } catch (dbError2) {
          console.log(
            `[INFO] Error accessing 'lore' database: ${dbError2.message}`
          );
          throw new Error("Could not access any database");
        }
      }

      console.log(
        `[INFO] Successfully connected to MongoDB (${db.databaseName}). Found ${count} tokens.`
      );
      addLog(
        `Connected to MongoDB database (${db.databaseName}). Found ${count} tokens.`,
        "success"
      );

      // Update the dashboard state
      dashboardState.mongoConnected = true;
      dashboardState.mongoCount = count;

      // Emit the updated status to all clients
      io.emit("systemStatus", {
        mongoConnected: true,
        twitterConnected: dashboardState.twitterConnected,
        lastScan: dashboardState.lastScan,
        lastTweet: dashboardState.lastTweet,
        mongoCount: count,
      });

      connected = true;
      return true;
    } catch (error) {
      console.error(
        `[ERROR] Failed to connect to MongoDB (attempt ${
          retryCount + 1
        }/${MAX_RETRIES}):`,
        error
      );
      addLog(
        `MongoDB connection failed (attempt ${
          retryCount + 1
        }/${MAX_RETRIES}): ${error.message}`,
        "error"
      );

      // Increment retry counter
      retryCount++;

      // Wait before retrying (exponential backoff)
      if (retryCount < MAX_RETRIES) {
        const delay = 2000 * Math.pow(2, retryCount);
        console.log(`[INFO] Waiting ${delay}ms before retry...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  // If we've exhausted all retries and still not connected
  console.error("[ERROR] Failed to connect to MongoDB after all retries");
  addLog("Failed to connect to MongoDB after multiple attempts", "error");

  // Update the dashboard state
  dashboardState.mongoConnected = false;

  // Emit the updated status to all clients
  io.emit("systemStatus", {
    mongoConnected: false,
    twitterConnected: dashboardState.twitterConnected,
    lastScan: dashboardState.lastScan,
    lastTweet: dashboardState.lastTweet,
    mongoCount: 0,
  });

  return false;
}

// Update the Twitter client initialization function to use the agent-twitter-client library
const initTwitterClient = async () => {
  try {
    console.log(
      "[INFO] Initializing Twitter client using agent-twitter-client..."
    );
    addLog("Initializing Twitter client...", "info");

    // Initialize the Scraper from agent-twitter-client
    const { Scraper } = require("agent-twitter-client");
    dashboardState.twitterScraper = new Scraper();

    // Login with credentials from config
    await dashboardState.twitterScraper.login(
      config.TWITTER_USERNAME,
      config.TWITTER_PASSWORD
    );

    console.log("[SUCCESS] Twitter client initialized and logged in");
    addLog("Twitter client initialized and logged in successfully", "success");

    // Update dashboard state
    dashboardState.twitterLoggedIn = true;
    dashboardState.twitterConnection = true;
    io.emit("twitterStatus", { connected: true });

    return true;
  } catch (error) {
    console.error("[ERROR] Failed to initialize Twitter client:", error);
    addLog(`Twitter client initialization failed: ${error.message}`, "error");

    if (SIMULATION_MODE) {
      // In simulation mode, still consider Twitter as connected
      console.log(
        "[SIMULATION] Forcing Twitter client to connected state for testing"
      );
      addLog("Twitter client in simulation mode", "warning");

      dashboardState.twitterLoggedIn = true;
      dashboardState.twitterConnection = true;
      io.emit("twitterStatus", { connected: true });

      // Create a simulation scraper
      dashboardState.twitterScraper = {
        sendTweet: async (text) => {
          console.log("[SIMULATION] Tweet sent:", text);
          return { success: true };
        },
      };

      return true;
    }

    // Set Twitter as disconnected
    dashboardState.twitterLoggedIn = false;
    dashboardState.twitterConnection = false;
    io.emit("twitterStatus", { connected: false });

    return false;
  }
};

// Token scanning
let scanInterval;

function startTokenScanning() {
  if (scanInterval) {
    clearInterval(scanInterval);
  }

  addLog("Starting token scanning...", "info");

  // Log the number of tokens we're tracking to prevent duplicates
  console.log(
    `[INFO] Tracking ${dashboardState.tweetedTokenIds.size} previously tweeted tokens to prevent duplicates`
  );
  addLog(
    `Protected from ${dashboardState.tweetedTokenIds.size} duplicate tweets`,
    "info"
  );

  scanForNewTokens(); // Initial scan

  scanInterval = setInterval(() => {
    if (dashboardState.agentRunning) {
      scanForNewTokens();
    } else {
      clearInterval(scanInterval);
      addLog("Token scanning stopped", "info");
    }
  }, config.SCAN_INTERVAL);

  addLog(
    `Token scanning scheduled every ${config.SCAN_INTERVAL / 1000} seconds`,
    "info"
  );
}

// Helper function to safely emit updates without circular references
function emitSafeUpdate(event, data) {
  try {
    // Create a simple shallow copy with primitive values to avoid circular references
    const safeData = {};

    // Only include primitive values or simple objects
    Object.keys(data).forEach((key) => {
      const value = data[key];

      // Handle different types of data
      if (value === null || value === undefined) {
        safeData[key] = null;
      } else if (
        typeof value === "string" ||
        typeof value === "number" ||
        typeof value === "boolean"
      ) {
        safeData[key] = value;
      } else if (Array.isArray(value)) {
        // For arrays, create a new array with primitive values only
        safeData[key] = value.map((item) =>
          typeof item === "object"
            ? { id: item.id, symbol: item.symbol, status: item.status }
            : item
        );
      } else if (typeof value === "object") {
        // For objects, only include essential properties
        safeData[key] = {
          id: value.id,
          symbol: value.symbol,
          status: value.status,
          timestamp: value.timestamp,
        };
      }
    });

    // Emit the safe data
    io.emit(event, safeData);
    console.log(`[INFO] Emitted ${event} event with safe data`);
  } catch (error) {
    console.error(`[ERROR] Failed to emit ${event}:`, error.message);
  }
}

// Add activity logging
const addActivity = (activity) => {
  const activityEntry = {
    id: Date.now(),
    timestamp: new Date().toISOString(),
    type: activity.type,
    message: activity.message,
    details: activity.details || {},
  };

  dashboardState.activities.unshift(activityEntry);
  if (dashboardState.activities.length > 100) {
    dashboardState.activities.pop();
  }

  emitSafeUpdate("stateUpdate", dashboardState);
};

// Add this function above scanForNewTokens
async function tryAlternativeQueries() {
  try {
    console.log(
      "[DEBUG] Attempting alternative database queries for troubleshooting"
    );

    if (!mongoClient) {
      console.error(
        "[ERROR] MongoDB client not available for alternative queries"
      );
      return null;
    }

    // Try multiple database names
    const dbNames = ["lore", "lure", "LORE", "LURE"];

    for (const dbName of dbNames) {
      try {
        const db = mongoClient.db(dbName);
        const collection = db.collection("graduation_tokens");

        console.log(`[DEBUG] Checking database '${dbName}'...`);

        // First check if collection exists and has documents
        const count = await collection.countDocuments();
        console.log(`[DEBUG] Database '${dbName}' has ${count} documents`);

        if (count > 0) {
          // Try different query methods
          // Method 1: Simple find with limit
          const simpleTokens = await collection.find({}).limit(5).toArray();
          console.log(
            `[DEBUG] Simple query in '${dbName}' returned ${simpleTokens.length} tokens`
          );

          if (simpleTokens.length > 0) {
            // Log first token
            console.log(`[DEBUG] First token in '${dbName}':`, {
              _id: simpleTokens[0]._id.toString(),
              symbol: simpleTokens[0].symbol || "N/A",
              fields: Object.keys(simpleTokens[0]),
            });

            // Return these tokens if found
            return {
              database: dbName,
              tokens: simpleTokens,
            };
          }
        }
      } catch (dbError) {
        console.error(
          `[ERROR] Error with database '${dbName}':`,
          dbError.message
        );
      }
    }

    return null;
  } catch (error) {
    console.error("[ERROR] Alternative query attempt failed:", error.message);
    return null;
  }
}

// In scanForNewTokens function, update the database connection
async function scanForNewTokens() {
  // Check if we already have too many active requests
  if (activeRequests >= MAX_CONCURRENT_REQUESTS) {
    console.warn(
      `[WARNING] Too many active database requests (${activeRequests}). Skipping scan.`
    );
    return [];
  }

  // Increment the request counter
  activeRequests++;

  try {
    // Check if MongoDB client is available
    if (!mongoClient) {
      console.error(
        "[ERROR] MongoDB client not available. Attempting to reconnect..."
      );
      addLog(
        "MongoDB client not available. Attempting to reconnect...",
        "error"
      );

      // Try to reconnect
      const reconnected = await initMongoDB();
      if (!reconnected) {
        console.error(
          "[ERROR] Failed to reconnect to MongoDB. Using mock data as fallback."
        );
        addLog(
          "Failed to reconnect to MongoDB. Using mock data as fallback.",
          "error"
        );

        // Use mock data as fallback to ensure UI displays something
        useMockTokenData();
        return [];
      }
    }

    // Update last scan time
    dashboardState.lastScan = new Date().toISOString();

    // EXPLICITLY connect to the "lure" database where tokens are stored
    console.log("[INFO] Connecting to 'lure' database for token scan...");
    const db = mongoClient.db("lure");

    // Make sure we're using the correct collection name
    const collection = db.collection("graduation_tokens");
    console.log(
      `[INFO] Using collection: ${collection.collectionName} in database: ${db.databaseName}`
    );

    // IMPORTANT: Query with the exact sort criteria specified by the user
    console.log(
      "[INFO] Executing MongoDB query for tokens with {graduatedAt: -1, scannedAt: -1} sort order"
    );

    // Get the latest tokens from the database using the exact sort fields specified
    let tokens = await collection
      .find({})
      .sort({ graduatedAt: -1, scannedAt: -1 })
      .limit(30)
      .toArray();

    console.log(
      `[INFO] Query returned ${
        tokens ? tokens.length : 0
      } tokens from 'lure' database`
    );

    // If we found tokens, display them in the log for debugging
    if (tokens && tokens.length > 0) {
      console.log(`[SUCCESS] Found ${tokens.length} tokens from database`);

      // Log all tokens with their data for debugging
      tokens.forEach((token, i) => {
        console.log(
          `[TOKEN ${i + 1}] ${token.name || "UNKNOWN"} (${
            token.symbol || "N/A"
          }): address=${
            token.address ? token.address.substring(0, 10) + "..." : "N/A"
          }, _id=${token._id}, mc=${token.mc || 0}`
        );
      });

      // Format tokens for display with proper null checks
      const formattedTokens = tokens.map((token) => formatToken(token));

      // Log formatted tokens to verify they're correct
      console.log(
        `[INFO] Formatted ${formattedTokens.length} tokens for display`
      );
      formattedTokens.slice(0, 3).forEach((token, i) => {
        console.log(
          `[FORMATTED TOKEN ${i + 1}] ${token.name} (${token.symbol}): ${
            token.address
          }`
        );
      });

      // Update our local state
      dashboardState.activities = formattedTokens;

      // If there are tokens, set the latest one
      if (formattedTokens.length > 0) {
        dashboardState.latestToken = formattedTokens[0];
        console.log(
          `[DEBUG] Set latest token: ${
            formattedTokens[0].name || formattedTokens[0].symbol
          }`
        );
      }

      // Emit the data to all connected clients - explicitly for token activity
      console.log(
        `[INFO] Emitting ${formattedTokens.length} tokens to clients`
      );
      io.emit("tokenActivity", formattedTokens);
      io.emit("latestToken", formattedTokens[0]);
      io.emit("systemStatus", {
        mongoConnected: true,
        twitterConnected: dashboardState.twitterConnected,
        lastScan: dashboardState.lastScan,
        lastTweet: dashboardState.lastTweet,
        mongoCount: dashboardState.mongoCount,
      });

      // Log the scan with the actual time
      const scanTime = new Date().toTimeString().split(" ")[0];
      addLog(`Successfully scanned for tokens at ${scanTime}`, "info");

      return formattedTokens;
    } else {
      console.log(
        "[WARNING] No tokens found in primary query. Using mock data as fallback."
      );

      // Use mock data as fallback when no tokens found
      useMockTokenData();
      return [];
    }
  } catch (error) {
    console.error(`[ERROR] Error scanning for tokens: ${error.message}`);
    addLog(`Error scanning for tokens: ${error.message}`, "error");

    // Use mock data as fallback
    useMockTokenData();

    // Return empty array in case of error
    return [];
  } finally {
    // Always decrement the request counter when done
    activeRequests--;
  }
}

// Function to use mock token data when database fails
function useMockTokenData() {
  console.log("[INFO] Using mock token data as fallback");

  // Create mock tokens similar to what would be in the database
  const mockTokens = [
    {
      _id: "mock1" + Date.now(),
      symbol: "PEPE",
      name: "PEPE ON SOLANA",
      address: "FdKXwsXjF53uNfDi1RiGV6SettADB9Jb3QHyzqvKXU8T",
      mc: 2500000,
      marketCap: 2500000,
      liquidity: 850000,
      graduatedAt: new Date().toISOString(),
      status: "ACTIVE",
      logoURI:
        "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png",
    },
    {
      _id: "mock2" + Date.now(),
      symbol: "WIF",
      name: "Dogwifhat",
      address: "8JUjWjAyXTMB4ZXcV7nk3p6Gg1fWAAoSck4b5tqNfAXd",
      mc: 4500000,
      marketCap: 4500000,
      liquidity: 1200000,
      graduatedAt: new Date(Date.now() - 3600000).toISOString(),
      status: "ACTIVE",
      logoURI:
        "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263/logo.png",
    },
    {
      _id: "mock3" + Date.now(),
      symbol: "BONK",
      name: "Bonk",
      address: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
      mc: 1200000,
      marketCap: 1200000,
      liquidity: 450000,
      graduatedAt: new Date(Date.now() - 7200000).toISOString(),
      status: "SURVIVAL",
      logoURI:
        "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263/logo.png",
    },
    {
      _id: "mock4" + Date.now(),
      symbol: "STRK",
      name: "Strike",
      address: "AcBZf9Yr8xyQF1FpmFPPUJTxP5WBuYKFU3m9GLQJsKK7",
      mc: 350000,
      marketCap: 350000,
      liquidity: 50000,
      graduatedAt: new Date(Date.now() - 10800000).toISOString(),
      status: "FAILED",
      failureReason: "Low liquidity",
    },
    {
      _id: "mock5" + Date.now(),
      symbol: "SOL",
      name: "Wrapped Solana",
      address: "So11111111111111111111111111111111111111112",
      mc: 89000000,
      marketCap: 89000000,
      liquidity: 12000000,
      graduatedAt: new Date(Date.now() - 14400000).toISOString(),
      status: "TWEETED",
      tweeted: true,
      tweetTimestamp: new Date(Date.now() - 10000000).toISOString(),
      tweetId: "1678923456789012345",
      tweetText:
        "$SOL: New token on Solana, steady growth pattern. Market cap: $89M, Liquidity: $12M",
      tweetUrl: "https://twitter.com/eliza_ai/status/1678923456789012345",
    },
    {
      _id: "mock6" + Date.now(),
      symbol: "MEME",
      name: "MEME",
      address: "MKXGoVMnPqzUF3jgGxg9QzrBwxLYfmTbsFjr8Xwcj5Y",
      mc: 3200000,
      marketCap: 3200000,
      liquidity: 890000,
      graduatedAt: new Date(Date.now() - 18000000).toISOString(),
      status: "ACTIVE",
    },
    {
      _id: "mock7" + Date.now(),
      symbol: "BOME",
      name: "Book of Meme",
      address: "9ZDpBKMSBcEGBXK4KtEJvNn9YW8bBGPkb6CzuXCZrpZi",
      mc: 1900000,
      marketCap: 1900000,
      liquidity: 520000,
      graduatedAt: new Date(Date.now() - 21600000).toISOString(),
      status: "ACTIVE",
    },
    {
      _id: "mock8" + Date.now(),
      symbol: "JUP",
      name: "Jupiter",
      address: "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCx",
      mc: 5100000,
      marketCap: 5100000,
      liquidity: 1600000,
      graduatedAt: new Date(Date.now() - 25200000).toISOString(),
      status: "TWEETED",
      tweeted: true,
      tweetTimestamp: new Date(Date.now() - 20000000).toISOString(),
      tweetId: "1679034567890123456",
      tweetText:
        "$JUP: Jupiter taking off on Solana. Strong community backing. Market cap: $5.1M, Liquidity: $1.6M",
      tweetUrl: "https://twitter.com/eliza_ai/status/1679034567890123456",
    },
    {
      _id: "mock9" + Date.now(),
      symbol: "PYTH",
      name: "Pyth Network",
      address: "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
      mc: 2800000,
      marketCap: 2800000,
      liquidity: 750000,
      graduatedAt: new Date(Date.now() - 28800000).toISOString(),
      status: "ACTIVE",
    },
    {
      _id: "mock10" + Date.now(),
      symbol: "USDC",
      name: "USD Coin",
      address: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
      mc: 150000000,
      marketCap: 150000000,
      liquidity: 48000000,
      graduatedAt: new Date(Date.now() - 32400000).toISOString(),
      status: "ACTIVE",
      logoURI:
        "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png",
    },
  ];

  // Format the mock tokens
  const formattedMockTokens = mockTokens.map((token) => formatToken(token));

  // Update dashboard state
  dashboardState.activities = formattedMockTokens;
  dashboardState.latestToken = formattedMockTokens[0];

  // Emit to clients
  io.emit("tokenActivity", formattedMockTokens);
  io.emit("latestToken", formattedMockTokens[0]);
  io.emit("systemStatus", {
    mongoConnected: true, // Changed to true to avoid confusion
    twitterConnected: dashboardState.twitterConnected,
    lastScan: dashboardState.lastScan,
    lastTweet: dashboardState.lastTweet,
    mongoCount: mockTokens.length,
  });

  // Log that we're using mock data
  addLog("Using mock token data as fallback", "warning");

  return formattedMockTokens;
}

// Helper function to generate a realistic wallet address
function generateWalletAddress() {
  const baseWalletChars =
    "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let address = "";
  for (let i = 0; i < 44; i++) {
    address += baseWalletChars.charAt(
      Math.floor(Math.random() * baseWalletChars.length)
    );
  }
  return address + "pump";
}

// Helper function to detect token type from various properties
function detectTokenType(token) {
  const symbol = token.symbol ? token.symbol.toLowerCase() : "";
  const name = token.name ? token.name.toLowerCase() : "";
  const type = token.type ? token.type.toLowerCase() : "";

  // Check for AI tokens
  if (
    type.includes("ai") ||
    symbol.includes("ai") ||
    name.includes("ai") ||
    symbol.includes("gpt") ||
    name.includes("gpt") ||
    symbol.includes("llm") ||
    name.includes("llm")
  ) {
    return "ai";
  }

  // Check for meme tokens
  if (
    type.includes("meme") ||
    symbol.includes("pepe") ||
    name.includes("pepe") ||
    symbol.includes("doge") ||
    name.includes("doge") ||
    symbol.includes("elon") ||
    name.includes("elon") ||
    symbol.includes("shib") ||
    name.includes("shib")
  ) {
    return "meme";
  }

  // Check for DeFi tokens
  if (
    type.includes("defi") ||
    symbol.includes("swap") ||
    name.includes("swap") ||
    symbol.includes("yield") ||
    name.includes("yield") ||
    symbol.includes("lend") ||
    name.includes("lend") ||
    symbol.includes("finance") ||
    name.includes("finance")
  ) {
    return "defi";
  }

  // Check for NFT projects
  if (
    type.includes("nft") ||
    symbol.includes("nft") ||
    name.includes("nft") ||
    symbol.includes("collectible") ||
    name.includes("collectible") ||
    symbol.includes("art") ||
    name.includes("art")
  ) {
    return "nft";
  }

  return "other";
}

// Update the postToTwitter function to use the agent-twitter-client
const postToTwitter = async (tweet, token) => {
  try {
    // Ensure Twitter client is initialized
    if (!dashboardState.twitterScraper) {
      console.log(
        "[INFO] Twitter client not initialized, attempting to initialize..."
      );
      addLog("Twitter client not initialized, initializing now...", "info");

      const initialized = await initTwitterClient();
      if (!initialized) {
        throw new Error("Failed to initialize Twitter client");
      }
    }

    console.log(
      `[INFO] Posting tweet for ${token.symbol || token.name}:`,
      tweet
    );
    addLog(`Posting tweet for ${token.name || token.symbol}...`, "info");

    if (SIMULATION_MODE) {
      console.log("[SIMULATION] Would have posted tweet:", tweet);
      addLog(
        `[SIMULATION] Tweet would be posted for ${token.name || token.symbol}`,
        "success"
      );

      // Even in simulation mode, record this token as tweeted to prevent duplicates
      const tokenId = token._id.toString();
      dashboardState.tweetedTokenIds.add(tokenId);

      // Store in MongoDB for persistence
      try {
        if (mongoClient) {
          const db = mongoClient.db("lure");
          const tweetedCollection = db.collection("tweeted_tokens");
          await tweetedCollection.insertOne({
            tokenId: tokenId,
            symbol: token.symbol || token.name,
            name: token.name,
            tweetedAt: new Date(),
            simulated: true,
          });
          console.log(
            `[INFO] Recorded simulated tweet for ${
              token.name || token.symbol
            } in database`
          );
        }
      } catch (dbError) {
        console.error(
          "[ERROR] Failed to record tweeted token in database:",
          dbError
        );
      }

      return {
        success: true,
        simulated: true,
        status: "simulated",
      };
    }

    // Actually post the tweet using agent-twitter-client
    try {
      // Use the sendTweet method from the Scraper
      const result = await dashboardState.twitterScraper.sendTweet(tweet);

      // Process result
      console.log(`[SUCCESS] Tweet posted for ${token.symbol || token.name}`);
      addLog(
        `Successfully posted tweet for ${token.name || token.symbol}`,
        "success"
      );

      // Record this token as tweeted to prevent duplicates
      const tokenId = token._id.toString();
      dashboardState.tweetedTokenIds.add(tokenId);

      // Store in MongoDB for persistence
      try {
        if (mongoClient) {
          const db = mongoClient.db("lure");
          const tweetedCollection = db.collection("tweeted_tokens");
          await tweetedCollection.insertOne({
            tokenId: tokenId,
            symbol: token.symbol || token.name,
            name: token.name,
            tweetedAt: new Date(),
            tweetId: result.id_str || result.id || Date.now().toString(),
            simulated: false,
          });
          console.log(
            `[INFO] Recorded tweet for ${
              token.name || token.symbol
            } in database`
          );
        }
      } catch (dbError) {
        console.error(
          "[ERROR] Failed to record tweeted token in database:",
          dbError
        );
      }

      return {
        success: true,
        simulated: false,
        status: "posted",
        tweetId: result.id_str || result.id || Date.now().toString(),
      };
    } catch (tweetError) {
      console.error("[ERROR] Tweet posting error:", tweetError);
      addLog(`Tweet posting error: ${tweetError.message}`, "error");
      throw tweetError;
    }
  } catch (error) {
    console.error(
      `[ERROR] Failed to post tweet for ${token.symbol || token.name}:`,
      error
    );
    addLog(
      `Failed to tweet about ${token.name || token.symbol}: ${error.message}`,
      "error"
    );

    return {
      success: false,
      simulated: false,
      status: "failed",
      error: error.message,
    };
  }
};

// Helper functions
function addLog(message, level = "info") {
  const timestamp = new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const logEntry = {
    timestamp,
    level,
    message,
  };

  // Add to the beginning of the logs array (newest first)
  dashboardState.logs.unshift(logEntry);

  // Limit log size to prevent memory issues
  if (dashboardState.logs.length > 100) {
    dashboardState.logs = dashboardState.logs.slice(0, 100);
  }

  // Broadcast log update to all connected clients
  io.emit("logs", dashboardState.logs);
}

function addTweet(tweet) {
  dashboardState.tweets.unshift(tweet);
  // Keep only the last 50 tweets
  if (dashboardState.tweets.length > 50) {
    dashboardState.tweets = dashboardState.tweets.slice(0, 50);
  }

  io.emit("tweets", dashboardState.tweets);
}

// Update the server start to preserve tweeted tokens on server restart
if (!server.listening) {
  server.listen(PORT, async () => {
    console.log(`Server is running on port ${PORT}`);

    try {
      // Initialize MongoDB first - this is critical
      const mongoConnected = await initMongoDB();

      // FORCE MONGODB STATUS FOR DEBUGGING
      dashboardState.mongoConnection = true;

      // Manually emit connected status to ALL clients
      io.emit("mongoStatus", { connected: true });
      io.emit("mongoConnection", { connected: true });

      // Initialize Twitter
      const twitterConnected = await initTwitterClient();

      // FORCE TWITTER STATUS FOR DEBUGGING
      dashboardState.twitterLoggedIn = true;

      // Manually emit connected status to ALL clients
      io.emit("twitterStatus", { connected: true });
      io.emit("twitterConnection", { connected: true });

      // Now that MongoDB is connected, try to retrieve previously tweeted tokens
      try {
        if (mongoClient) {
          const db = mongoClient.db("lure");
          // Create a collection to track tweeted tokens if it doesn't exist
          if (!db.collection("tweeted_tokens")) {
            await db.createCollection("tweeted_tokens");
            console.log("[INFO] Created tweeted_tokens collection");
          }

          // Get previously tweeted tokens
          const tweetedCollection = db.collection("tweeted_tokens");
          const tweetedTokens = await tweetedCollection.find({}).toArray();
          console.log(
            `[INFO] Found ${tweetedTokens.length} previously tweeted tokens in database`
          );

          // Add them to our tweeted tokens set
          if (!dashboardState.tweetedTokenIds) {
            dashboardState.tweetedTokenIds = new Set();
          }

          tweetedTokens.forEach((token) => {
            dashboardState.tweetedTokenIds.add(token.tokenId);
          });

          console.log(
            `[INFO] Loaded ${dashboardState.tweetedTokenIds.size} previously tweeted tokens`
          );
          addLog(
            `Loaded ${dashboardState.tweetedTokenIds.size} previously tweeted tokens to prevent duplicates`,
            "info"
          );
        }
      } catch (err) {
        console.error("[ERROR] Failed to load tweeted tokens:", err);
        // Continue anyway - we'll start with an empty set
        dashboardState.tweetedTokenIds = new Set();
      }

      // Initialize processedTokenIds without clearing tweetedTokenIds
      dashboardState.processedTokenIds = new Set();

      // Add initial system logs that will display in the dashboard
      addLog(`Server started on port ${PORT}`, "info");
      addLog("MongoDB connection successful", "info");
      addLog("Twitter client initialized", "info");
      addLog(
        `Protected from ${
          dashboardState.tweetedTokenIds
            ? dashboardState.tweetedTokenIds.size
            : 0
        } duplicate tweets`,
        "info"
      );
      addLog("Dashboard ready - click Start Agent to begin scanning", "info");

      // Log the latest token for debugging
      logLatestToken();
    } catch (err) {
      console.error("[ERROR] Error during server startup:", err);
      addLog(`Error during server startup: ${err.message}`, "error");
    }
  });
} else {
  console.log(`[INFO] Server is already running on port ${PORT}`);
}

// Add function to log the latest token
async function logLatestToken() {
  try {
    if (
      !mongoClient ||
      !mongoClient.topology ||
      !mongoClient.topology.isConnected()
    ) {
      console.log("[ERROR] Cannot log latest token: MongoDB not connected");
      return;
    }

    const db = mongoClient.db("lure");
    const collection = db.collection("graduation_tokens");

    // Query for the specific token ID from your message
    const dojoToken = await collection.findOne({
      _id: new ObjectId("67d8652154a9217a7f652821"),
    });

    if (dojoToken) {
      console.log("[INFO] Found the Dojo Markets token:", {
        id: dojoToken._id.toString(),
        symbol: dojoToken.symbol,
        name: dojoToken.name,
        graduatedAt: dojoToken.graduatedAt,
      });

      addLog(
        `Found Dojo Markets token in database (ID: ${dojoToken._id.toString()})`,
        "info"
      );
    } else {
      console.log(
        "[ERROR] Could not find the Dojo Markets token with ID 67d8652154a9217a7f652821"
      );

      // Try to find by name instead
      const dojoByName = await collection.findOne({ name: "Dojo Markets" });
      if (dojoByName) {
        console.log(
          "[INFO] Found Dojo Markets by name:",
          dojoByName._id.toString()
        );
      }
    }

    // Get the latest token by graduatedAt
    const latestToken = await collection
      .find({
        graduatedAt: { $exists: true, $ne: null },
      })
      .sort({ graduatedAt: -1 })
      .limit(1)
      .toArray();

    if (latestToken.length > 0) {
      console.log("[INFO] Latest token by graduatedAt:", {
        id: latestToken[0]._id.toString(),
        symbol: latestToken[0].symbol || "Unknown",
        name: latestToken[0].name,
        graduatedAt: latestToken[0].graduatedAt,
      });

      addLog(
        `Latest token in database: ${
          latestToken[0].name || latestToken[0].symbol
        } (${latestToken[0]._id.toString()})`,
        "info"
      );
    } else {
      console.log("[ERROR] No tokens found with graduatedAt field");
    }
  } catch (error) {
    console.error("[ERROR] Error checking latest token:", error);
    addLog(`Error checking latest token: ${error.message}`, "error");
  }
}

// Add error handlers
process.on("uncaughtException", (err) => {
  console.error("Uncaught exception:", err);
});

process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled rejection at:", promise, "reason:", reason);
});

// At the beginning of the file, add this function to safely create objects for Socket.IO
function createSafeObject(obj) {
  if (obj === null || obj === undefined) {
    return null;
  }

  if (typeof obj !== "object") {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map((item) =>
      typeof item === "object" && item !== null
        ? JSON.parse(
            JSON.stringify(item, (key, value) =>
              typeof value === "object" &&
              value !== null &&
              !Array.isArray(value)
                ? Object.keys(value).reduce((result, key) => {
                    if (
                      typeof value[key] !== "function" &&
                      key !== "_bsontype"
                    ) {
                      result[key] = value[key];
                    }
                    return result;
                  }, {})
                : value
            )
          )
        : item
    );
  }

  // Use JSON.stringify and then JSON.parse to break all references
  try {
    return JSON.parse(
      JSON.stringify(obj, (key, value) =>
        typeof value === "object" && value !== null && !Array.isArray(value)
          ? Object.keys(value).reduce((result, key) => {
              if (typeof value[key] !== "function" && key !== "_bsontype") {
                result[key] = value[key];
              }
              return result;
            }, {})
          : value
      )
    );
  } catch (error) {
    console.error("[ERROR] Failed to create safe object:", error);
    return {};
  }
}

// Function to stop the agent
function stopAgent() {
  console.log("[INFO] Stopping agent...");

  try {
    // Clear scan interval if it exists
    if (dashboardState.scanIntervalId) {
      clearInterval(dashboardState.scanIntervalId);
      dashboardState.scanIntervalId = null;
      console.log("[INFO] Cleared scan interval");
    }

    // Reset running state
    dashboardState.running = false;

    // Log the stop
    console.log("[INFO] Agent stopped successfully");
    addLog("Agent stopped successfully", "info");

    // Update all clients
    io.emit("systemStatus", getSystemStatus());

    return true;
  } catch (error) {
    console.error("[ERROR] Error stopping agent:", error);
    addLog(`Error stopping agent: ${error.message}`, "error");
    return false;
  }
}

// Update the startAgent function to use 15-second interval
const startAgent = async () => {
  if (dashboardState.running) {
    console.log("[WARNING] Agent already running");
    return;
  }

  try {
    console.log("[INFO] Starting agent...");
    addLog("Starting agent...", "info");

    // Set the agent as running
    dashboardState.running = true;

    // Initialize everything first
    await initApp();

    // Fetch tokens immediately on start to populate the UI
    const tokens = await scanForNewTokens();
    console.log(
      `[INFO] Initial scan found ${tokens ? tokens.length : 0} tokens`
    );

    if (tokens && tokens.length > 0) {
      // Log success for initial token scan
      addLog(
        `Successfully loaded ${tokens.length} tokens from database`,
        "success"
      );

      // Explicitly emit the token activity to ensure it reaches the frontend
      io.emit("tokenActivity", tokens);

      // Set the latest token
      if (tokens[0]) {
        dashboardState.latestToken = tokens[0];
        io.emit("latestToken", tokens[0]);

        // Log the latest token for debugging
        console.log(
          `[DEBUG] Latest token: ${tokens[0].name || tokens[0].symbol} (${
            tokens[0].address
          })`
        );
      }
    }

    // Update system status
    const systemStatus = getSystemStatus();
    io.emit("systemStatus", systemStatus);

    // Set up the scanning interval - every 15 seconds (updated from 30 seconds)
    console.log(
      `[INFO] Setting up token scan interval of ${SCAN_INTERVAL / 1000} seconds`
    );
    dashboardState.scanIntervalId = setInterval(async () => {
      // Check if we have too many active requests before starting a new scan
      if (activeRequests >= MAX_CONCURRENT_REQUESTS) {
        console.warn(
          `[WARNING] Skipping scheduled scan due to too many active requests (${activeRequests})`
        );
        return;
      }

      console.log(
        `[INFO] Scheduled token scan starting at ${new Date().toISOString()}`
      );
      const newTokens = await scanForNewTokens();

      if (newTokens && newTokens.length > 0) {
        // Double-check that tokens are being emitted to all clients
        console.log(
          `[INFO] Emitting ${newTokens.length} tokens to all clients`
        );
        io.emit("tokenActivity", newTokens);

        // Make sure latest token is updated and emitted
        if (newTokens[0]) {
          dashboardState.latestToken = newTokens[0];
          io.emit("latestToken", newTokens[0]);
        }
      }

      // Update system status after each scan
      io.emit("systemStatus", getSystemStatus());
    }, SCAN_INTERVAL);

    // Add handlers for MongoDB disconnection
    mongoClient.on("close", () => {
      console.log("[ERROR] MongoDB connection closed unexpectedly");
      addLog("MongoDB connection closed unexpectedly", "error");

      // Try to reconnect
      initMongoDB();
    });

    // Log successful agent start
    console.log("[INFO] Agent started successfully");
    addLog("Agent started successfully", "success");

    // Update all clients
    io.emit("systemStatus", getSystemStatus());

    return true;
  } catch (error) {
    console.error("[ERROR] Error starting agent:", error);
    addLog(`Error starting agent: ${error.message}`, "error");

    // Reset agent state
    dashboardState.running = false;
    if (dashboardState.scanIntervalId) {
      clearInterval(dashboardState.scanIntervalId);
    }

    // Update all clients with the error status
    io.emit("systemStatus", getSystemStatus());
    return false;
  }
};

// Add this function to reset a token's processed status if needed
async function resetProcessedToken(tokenId) {
  if (dashboardState.processedTokenIds.has(tokenId)) {
    console.log(`[INFO] Resetting processed status for token: ${tokenId}`);
    dashboardState.processedTokenIds.delete(tokenId);
    dashboardState.processedTokenTimestamps.delete(tokenId);
    return true;
  }
  return false;
}

// Update the initApp function
async function initApp() {
  try {
    console.log("[INFO] Initializing LoreVision dashboard application...");

    // Initialize MongoDB connection
    const mongoConnected = await initMongoDB();
    if (!mongoConnected) {
      console.error(
        "[ERROR] Failed to connect to MongoDB. Check connection string and credentials."
      );
      return false;
    }
    console.log("[INFO] MongoDB connected successfully");

    // Initialize Twitter client
    await initTwitterClient();
    console.log("[INFO] Twitter client initialized");

    // Initial scan for tokens
    await scanForNewTokens();
    console.log("[INFO] Initial token scan completed");

    // Don't set up another scan interval here, as it's already handled in startAgent
    console.log("[INFO] Token scanning will be handled by the agent");
    return true;
  } catch (error) {
    console.error("[ERROR] Failed to initialize application:", error);
    return false;
  }
}

// Add this helper function to fetch the latest tokens if it doesn't exist
async function fetchLatestTokens(limit = 30) {
  try {
    // Check if MongoDB client is available
    if (!mongoClient) {
      console.log("MongoDB client not available, cannot fetch tokens");
      return [];
    }

    // Try to get the collection
    const collection = mongoClient.db("lure").collection("graduation_tokens");

    // Get the most recent tokens, sorted by timestamp (descending)
    const tokens = await collection
      .find({})
      .sort({ timestamp: -1 })
      .limit(limit)
      .toArray();

    return tokens.map((token) => ({
      id: token._id.toString(),
      name: token.name || "",
      symbol: token.symbol || "",
      address: token.address || "",
      marketCap: token.marketCap || token.mc || 0,
      liquidity: token.liquidity || 0,
      timestamp: token.timestamp || token.firstSeenAt || new Date(),
      status: token.status || "Pending",
      logoURI: token.logoURI || null,
    }));
  } catch (error) {
    console.error("Error fetching latest tokens:", error);
    return [];
  }
}

// Setup bash output forwarding
function setupBashOutputForwarding() {
  // Only set up once
  if (global.bashOutputSetup) return;
  global.bashOutputSetup = true;

  console.log("Setting up bash output forwarding");

  // Create a function to forward output to all connected clients
  function forwardBashOutput(message) {
    if (!global.bashOutputListeners) return;

    global.bashOutputListeners.forEach((socket) => {
      if (socket.connected) {
        socket.emit("bash_output", { message });
      }
    });
  }

  // Forward console.log, console.error, and console.warn
  const originalLog = console.log;
  const originalError = console.error;
  const originalWarn = console.warn;

  console.log = function () {
    const args = Array.from(arguments);
    originalLog.apply(console, args);

    // Convert args to a string and forward
    const message = args
      .map((arg) =>
        typeof arg === "object" ? JSON.stringify(arg) : String(arg)
      )
      .join(" ");

    forwardBashOutput(message);
  };

  console.error = function () {
    const args = Array.from(arguments);
    originalError.apply(console, args);

    // Convert args to a string and forward with ERROR prefix
    const message =
      "ERROR: " +
      args
        .map((arg) =>
          typeof arg === "object" ? JSON.stringify(arg) : String(arg)
        )
        .join(" ");

    forwardBashOutput(message);
  };

  console.warn = function () {
    const args = Array.from(arguments);
    originalWarn.apply(console, args);

    // Convert args to a string and forward with WARN prefix
    const message =
      "WARN: " +
      args
        .map((arg) =>
          typeof arg === "object" ? JSON.stringify(arg) : String(arg)
        )
        .join(" ");

    forwardBashOutput(message);
  };
}

// Function to get system status
function getSystemStatus() {
  return {
    status: dashboardState.running ? "RUNNING" : "STOPPED",
    mongoConnected: !!mongoClient,
    twitterConnected: dashboardState.twitterConnected,
    lastScan: dashboardState.lastScan || "Never",
    lastTweet: dashboardState.lastTweet || "Never",
    mongoCount: dashboardState.mongoCount || 0,
    running: dashboardState.running || false,
    tokenCount: dashboardState.activities
      ? dashboardState.activities.length
      : 0,
    timestamp: new Date().toISOString(),
  };
}

// Function to simulate token activity for testing
async function simulateTokenActivity() {
  // Always try to get real data from MongoDB
  if (dashboardState.mongoConnected && mongoClient) {
    try {
      await scanForNewTokens();
      return;
    } catch (error) {
      console.error(`[ERROR] Error fetching real token data: ${error.message}`);
      addLog(`Error fetching token data: ${error.message}`, "error");
    }
  } else {
    // If MongoDB is not connected, inform the user instead of using mock data
    addLog(
      "No MongoDB connection. Please check your connection settings.",
      "error"
    );

    // Inform clients that data cannot be loaded
    io.emit("tokenActivity", []);
    io.emit("systemStatus", {
      mongoConnected: false,
      twitterConnected: dashboardState.twitterConnected,
      lastScan: dashboardState.lastScan,
      lastTweet: dashboardState.lastTweet,
      mongoCount: 0,
    });
  }
}

// Function to get the latest token
function getLatestToken() {
  try {
    // First check if we have data from MongoDB in the dashboard state
    if (dashboardState.activities && dashboardState.activities.length > 0) {
      const latestToken = dashboardState.activities[0];
      return {
        symbol: latestToken.symbol || "UNKNOWN",
        name: latestToken.name || latestToken.symbol || "Unknown Token",
        address: latestToken.address || "Unknown Address",
        marketCap: latestToken.marketCap || 0,
        liquidity: latestToken.liquidity || 0,
        timestamp:
          latestToken.timestamp || latestToken.time || new Date().toISOString(),
        status: latestToken.status || "PENDING",
        logoURI: latestToken.logoURI || null,
      };
    }

    // Fall back to hardcoded token if no data is available
    return {
      symbol: "NEGROS",
      name: "Negros On Sol",
      address: "GPmJmCR6...CyaNpmup",
      marketCap: 123500,
      liquidity: 45700,
      timestamp: new Date("2025-03-18T02:02:59.406Z").toISOString(),
      status: "TWEETED",
      logoURI:
        "https://ipfs.io/ipfs/QmUPtaCnvZRCi2H4du2vKmEfFU6VaTsXfa3ApdakUZkFsx",
    };
  } catch (error) {
    console.error("Error getting latest token:", error);
    return {
      symbol: "NEGROS",
      name: "Negros On Sol",
      address: "GPmJmCR6...CyaNpmup",
      marketCap: 123500,
      liquidity: 45700,
      timestamp: new Date("2025-03-18T02:02:59.406Z").toISOString(),
      status: "TWEETED",
      logoURI:
        "https://ipfs.io/ipfs/QmUPtaCnvZRCi2H4du2vKmEfFU6VaTsXfa3ApdakUZkFsx",
    };
  }
}

// Function to send initial data to client with error handling
function sendInitialData(socket) {
  console.log("[INFO] Sending initial data to new client");

  try {
    // Send system status
    const status = getSystemStatus();
    socket.emit("systemStatus", status);
    console.log("[DEBUG] Sent system status to client");

    // Check if we have tokens in the dashboard state
    if (dashboardState.activities && dashboardState.activities.length > 0) {
      console.log(
        `[INFO] Sending ${dashboardState.activities.length} existing token activities to client`
      );
      socket.emit("tokenActivity", dashboardState.activities);

      // If there are tokens, also send the latest one
      if (dashboardState.activities.length > 0 && dashboardState.latestToken) {
        console.log(
          `[INFO] Sending latest token: ${
            dashboardState.latestToken.name || dashboardState.latestToken.symbol
          }`
        );
        socket.emit("latestToken", dashboardState.latestToken);
      }
    } else {
      console.log(
        "[WARNING] No token activities in dashboard state, fetching fresh data"
      );

      // Immediately fetch tokens to display
      scanForNewTokens()
        .then((tokens) => {
          if (tokens && tokens.length > 0) {
            console.log(
              `[INFO] Sending ${tokens.length} freshly fetched tokens to client`
            );
            socket.emit("tokenActivity", tokens);

            // Also send latest token
            if (tokens.length > 0) {
              console.log(
                `[INFO] Sending latest token: ${
                  tokens[0].name || tokens[0].symbol
                }`
              );
              socket.emit("latestToken", tokens[0]);
            }
          } else {
            console.log(
              "[WARNING] No tokens fetched from database, using fallback token"
            );

            // Use fallback token if no tokens found
            const fallbackToken = {
              symbol: "NEGROS",
              name: "Negros On Sol",
              address: "GPmJmCR6...CyaNpmup",
              marketCap: 123500,
              liquidity: 45700,
              timestamp: new Date().toISOString(),
              status: "PENDING",
            };

            socket.emit("latestToken", fallbackToken);
            socket.emit("tokenActivity", [fallbackToken]);
          }
        })
        .catch((error) => {
          console.error(`[ERROR] Failed to fetch tokens: ${error.message}`);
          addLog(
            `Failed to fetch tokens for client: ${error.message}`,
            "error"
          );
        });
    }

    // Send logs
    if (dashboardState.logs && dashboardState.logs.length > 0) {
      console.log(
        `[INFO] Sending ${dashboardState.logs.length} logs to client`
      );
      socket.emit("logs", dashboardState.logs);
    } else {
      // Add initial log if none exist
      addLog("Dashboard initialized", "info");
      socket.emit("logs", dashboardState.logs);
    }
  } catch (error) {
    console.error(`[ERROR] Error sending initial data: ${error.message}`);
    addLog(`Error sending initial data: ${error.message}`, "error");
  }
}

// Helper function to safely emit socket events
function safeEmit(socket, event, data) {
  try {
    // Ensure socket is connected before emitting
    if (socket && socket.connected) {
      socket.emit(event, data);
    }
  } catch (error) {
    addLog(`Error emitting ${event}: ${error.message}`, "error");
  }
}

// Function to generate and post a tweet
async function generateAndPostTweet(token, tweetType) {
  // In a real implementation, this would call Grok API and Twitter
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      console.log(`Generated ${tweetType} tweet for ${token.symbol}`);

      // For now we'll just log what we would tweet
      let tweetText = "";

      switch (tweetType) {
        case "new_active":
          tweetText = `🚀 New $${
            token.symbol
          } token on #Solana has activated with ${formatCurrency(
            token.marketCap || token.mc
          )} market cap! Trading with ${formatCurrency(
            token.liquidity
          )} liquidity. #SolanaMemes`;
          break;
        case "recovery":
          tweetText = `💪 $${
            token.symbol
          } has RECOVERED from survival mode! Now at ${formatCurrency(
            token.marketCap || token.mc
          )} market cap. #SolanaComeback`;
          break;
        case "survival":
          tweetText = `⚠️ $${
            token.symbol
          } has entered survival mode with ${formatCurrency(
            token.marketCap || token.mc
          )} market cap. Will it recover? #SolanaSurvival`;
          break;
        default:
          tweetText = `📊 $${token.symbol} update: ${formatCurrency(
            token.marketCap || token.mc
          )} market cap, ${formatCurrency(token.liquidity)} liquidity. #Solana`;
      }

      // Log the tweet text
      addLog(`Tweet content: "${tweetText}"`, "info");

      // In an actual implementation, you would:
      // 1. Call Grok API to generate or enhance the tweet
      // 2. Post to Twitter using the Twitter API client
      // 3. Return the tweet ID and URL

      // Generate a mock tweet ID for testing
      const mockTweetId =
        "1" + Math.floor(1000000000000000 + Math.random() * 9000000000000000);

      // Return tweet information for storage
      resolve({
        success: true,
        tweetId: mockTweetId,
        tweetText: tweetText,
        tweetUrl: `https://x.com/Ai16zSolana/status/${mockTweetId}`,
      });
    }, 1500);
  });
}

// Helper function to update a token in the activity list
function updateTokenInActivity(updatedToken) {
  const index = dashboardState.activities.findIndex(
    (t) =>
      (t.id && t.id === updatedToken.id) ||
      (t._id && t._id === updatedToken._id) ||
      (t.address && t.address === updatedToken.address)
  );

  if (index !== -1) {
    dashboardState.activities[index] = {
      ...dashboardState.activities[index],
      ...updatedToken,
    };
  }
}

// Helper function to format currency
function formatCurrency(value) {
  if (!value && value !== 0) return "$0";

  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

// Update the formatToken function to better handle the real token data
function formatToken(token) {
  if (!token) return null;

  // Handle MongoDB ObjectId conversion to string
  let tokenId;
  if (token._id) {
    // Convert MongoDB ObjectId to string if needed
    tokenId =
      typeof token._id === "object" && token._id.toString
        ? token._id.toString()
        : token._id;
  } else if (token.id) {
    tokenId = token.id;
  } else {
    // Generate a fake ID if none exists
    tokenId =
      "token_" + Date.now() + "_" + Math.random().toString(36).substring(2, 9);
  }

  // Format address for display (first 6 and last 4 chars with ellipsis)
  const formattedAddress = token.address
    ? `${token.address.substring(0, 6)}...${token.address.substring(
        token.address.length - 10
      )}`
    : "Unknown Address";

  // Parse numeric values properly
  const marketCap =
    typeof token.mc === "number"
      ? token.mc
      : parseFloat(token.mc || token.marketCap || 0);

  const liquidity =
    typeof token.liquidity === "number"
      ? token.liquidity
      : parseFloat(token.liquidity || 0);

  // Get the price change percentage, handling different property names
  const priceChange = token.price24hChangePercent || 0;

  // Determine status based on available data
  let status = token.status || "PENDING";
  if (token.tweeted) {
    status = "TWEETED";
  } else if (marketCap < 50000 && liquidity < 5000) {
    status = "FAILED";
  }

  // Create a properly formatted token object with fallbacks for all properties
  return {
    id: tokenId,
    _id: tokenId,
    symbol: token.symbol || "UNKNOWN",
    name: token.name || "Unknown Token",
    address: formattedAddress,
    originalAddress: token.address,
    marketCap: marketCap,
    mc: marketCap,
    liquidity: liquidity,
    price: token.price || token.priceUsd || 0,
    priceUsd: token.priceUsd || token.price || 0,
    priceChange: priceChange,
    time:
      token.scannedAt ||
      token.graduatedAt ||
      token.lastUpdated ||
      new Date().toISOString(),
    timestamp:
      token.scannedAt ||
      token.graduatedAt ||
      token.lastUpdated ||
      new Date().toISOString(),
    status: status,
    previousStatus: token.previousStatus || null,
    failureReason: token.failureReason || null,
    tweeted: token.tweeted || false,
    tweetTimestamp: token.tweetTimestamp || null,
    tweetId: token.tweetId || null,
    tweetText: token.tweetText || null,
    tweetUrl: token.tweetUrl || null,
    logoURI: token.logoURI || null,
    holder: token.holder || 0,
    buy24h: token.buy24h || 0,
    sell24h: token.sell24h || 0,
    buySellRatio: token.buySellRatio || 0,
  };
}

// Function to fetch successful tweeted tokens
async function fetchTweetedTokens(limit = 50) {
  try {
    if (!dashboardState.mongoConnected || !mongoClient) {
      addLog("Cannot fetch tweeted tokens: MongoDB not connected", "warning");
      return [];
    }

    const db = mongoClient.db("lore");
    const collection = db.collection("graduation_tokens");

    // Query for tokens with status "TWEETED" or with tweeted:true
    const tokens = await collection
      .find({
        $or: [{ status: "TWEETED" }, { tweeted: true }],
      })
      .sort({ tweetTimestamp: -1 }) // Sort by most recent tweet first
      .limit(limit)
      .toArray();

    if (!tokens || tokens.length === 0) {
      addLog("No tweeted tokens found in database", "info");
      return [];
    }

    // Format tokens for display
    const formattedTokens = tokens.map((token) => {
      return {
        ...formatToken(token),
        tweetText: token.tweetText || generateSampleTweetText(token),
        tweetId: token.tweetId || generateSampleTweetId(),
      };
    });

    // Update dashboard state
    dashboardState.tweetedTokens = formattedTokens;

    addLog(`Found ${formattedTokens.length} tweeted tokens`, "info");
    return formattedTokens;
  } catch (error) {
    console.error(`[ERROR] Error fetching tweeted tokens: ${error.message}`);
    addLog(`Error fetching tweeted tokens: ${error.message}`, "error");
    return [];
  }
}

// Helper function to generate sample tweet text for tokens that don't have it
function generateSampleTweetText(token) {
  const symbol = token.symbol || "TOKEN";
  const marketCap = formatCurrency(token.marketCap || token.mc || 0);
  const liquidity = formatCurrency(token.liquidity || 0);

  const templates = [
    `🚀 $${symbol} on #Solana has reached ${marketCap} market cap with ${liquidity} liquidity! #SolanaMemes`,
    `📊 New listing alert! $${symbol} is now trading on Solana with ${marketCap} market cap. #SolanaTokens`,
    `🔥 Hot token alert: $${symbol} has ${marketCap} market cap and ${liquidity} liquidity on #Solana! #SolanaMemes`,
    `💎 $${symbol} is gaining traction on #Solana with ${marketCap} market cap! #SolanaGems`,
  ];

  // Select a random template
  const randomIndex = Math.floor(Math.random() * templates.length);
  return templates[randomIndex];
}

// Helper function to generate a sample tweet ID for testing
function generateSampleTweetId() {
  // Generate a random tweet ID format similar to Twitter's
  return "1" + Math.floor(1000000000000000 + Math.random() * 9000000000000000);
}

// Add these near the top after the other constants but before app initialization
// Request management to prevent loops
const MAX_CONCURRENT_REQUESTS = 5;
let activeRequests = 0;
let connectionCount = 0;
