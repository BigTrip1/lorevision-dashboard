# LoreVision Dashboard

A real-time dashboard for monitoring Solana memecoins, built with Node.js, Express, Socket.io, and MongoDB.

## Features

- Real-time token monitoring from MongoDB database
- Display of token market cap, liquidity, and status
- System logs for monitoring application status
- 15-second automatic token data refresh interval
- Fallback to mock data if database is unavailable

## Setup

1. Clone the repository:

```bash
git clone https://github.com/BigTrip1/lorevision-dashboard.git
cd lorevision-dashboard
```

2. Install dependencies:

```bash
npm install
```

3. Start the dashboard:

```bash
# For Windows PowerShell
.\start-dashboard.ps1

# For Command Prompt
start-dashboard.bat

# Or using Node directly
node --max-old-space-size=4096 index.js
```

## Configuration

The dashboard connects to a MongoDB database to retrieve token data. The connection string and database name can be configured in the `index.js` file.

## License

MIT
